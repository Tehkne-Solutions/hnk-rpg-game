const clamp=(v,a,b)=>Math.max(a,Math.min(b,v));
function hash(i,seed=1){let x=Math.sin(i*12.9898+seed*78.233)*43758.5453;return x-Math.floor(x)}
export function vfxBudget(style,{quality=1}={}){
 return {
  clouds:Math.round(clamp(style.cloud*14*quality,0,14)),
  rain:Math.round(clamp(style.precipitation*180*quality,0,180)),
  mist:Math.round(clamp(style.fogBoost*42*quality,0,42)),
  windStreaks:Math.round(clamp(style.wind*34*quality,0,34)),
  stars:Math.round(clamp((style.nightFactor||0)*(1-style.cloud)*90*quality,0,90))
 };
}
export function deterministicParticles(kind,count,width,height,time=0,seed=17){
 const out=[];for(let i=0;i<count;i++){
  const a=hash(i,seed),b=hash(i+117,seed),c=hash(i+991,seed);
  if(kind==='rain')out.push({x:a*width,y:(b*height+time*(280+220*c))%height,len:8+16*c,drift:(c-.5)*8});
  else if(kind==='mist')out.push({x:(a*width+time*(8+15*c))%(width+160)-80,y:height*(.48+.5*b),r:35+95*c,alpha:.025+.05*c});
  else if(kind==='wind')out.push({x:(a*width+time*(60+110*c))%(width+80)-40,y:b*height,len:10+35*c,alpha:.05+.11*c});
  else if(kind==='star')out.push({x:a*width,y:b*height*.72,r:.4+1.25*c,alpha:.25+.7*c});
  else out.push({x:a*width,y:b*height,r:20+80*c,alpha:.1+.2*c});
 }
 return out;
}
export function weatherVfxDescriptor(style,quality=1){
 return {budget:vfxBudget(style,{quality}),windDirection:[1,0.18],rainAngle:style.wind*.22,mistHeight:style.fogBoost};
}
