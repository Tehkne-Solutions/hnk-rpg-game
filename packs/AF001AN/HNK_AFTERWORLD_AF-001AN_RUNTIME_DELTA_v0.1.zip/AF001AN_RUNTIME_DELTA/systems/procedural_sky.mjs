const clamp=(v,a,b)=>Math.max(a,Math.min(b,v));
const mix=(a,b,t)=>a.map((v,i)=>v+(b[i]-v)*t);
export function skyPalette({phase='DAY',cloud=0,fogBoost=0}={}){
 const P={
  DAWN:{zenith:[0.24,0.31,0.38],horizon:[0.72,0.58,0.42],sun:[0.95,0.72,0.42]},
  DAY:{zenith:[0.28,0.42,0.52],horizon:[0.62,0.69,0.68],sun:[0.96,0.90,0.70]},
  DUSK:{zenith:[0.22,0.25,0.32],horizon:[0.67,0.45,0.34],sun:[0.93,0.62,0.36]},
  NIGHT:{zenith:[0.035,0.05,0.075],horizon:[0.10,0.12,0.14],sun:[0.72,0.76,0.78]}
 };
 const p=P[phase]||P.DAY,gray=[0.38,0.40,0.40],mute=clamp(cloud*.42+fogBoost*.32,0,.72);
 return {zenith:mix(p.zenith,gray,mute),horizon:mix(p.horizon,gray,mute*.72),celestial:p.sun};
}
export function celestialPosition({hour=12,width=1000,height=600}={}){
 const h=((hour%24)+24)%24;
 const t=(h-6)/12*Math.PI;
 return {x:width*(.5+.48*Math.cos(Math.PI-t)),y:height*(.76-.63*Math.sin(t)),above:h>=5&&h<=20};
}
export function starVisibility({phase='DAY',cloud=0}={}){
 if(phase!=='NIGHT')return 0;
 return clamp(1-cloud*.92,0,1);
}
export function cloudOpacity({cloud=0,precipitation=0}={}){
 return clamp(.16+cloud*.58+precipitation*.16,0,.88);
}
export function skyDescriptor(style,hour){
 return {...skyPalette(style),celestial:celestialPosition({hour}),stars:starVisibility(style),cloudOpacity:cloudOpacity(style)};
}
