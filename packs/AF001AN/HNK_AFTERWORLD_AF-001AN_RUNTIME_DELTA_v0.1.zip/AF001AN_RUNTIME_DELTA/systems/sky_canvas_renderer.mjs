import {skyDescriptor} from './procedural_sky.mjs';
import {vfxBudget,deterministicParticles} from './weather_vfx.mjs';
const css=(rgb,a=1)=>`rgba(${rgb.map(v=>Math.round(v*255)).join(',')},${a})`;
export function createSkyRenderer(canvas){
 const ctx=canvas.getContext('2d',{alpha:false});
 return {canvas,ctx,time:0,last:null};
}
export function resizeSky(renderer,w,h,dpr=1){
 const W=Math.max(1,Math.floor(w*dpr)),H=Math.max(1,Math.floor(h*dpr));
 if(renderer.canvas.width!==W||renderer.canvas.height!==H){renderer.canvas.width=W;renderer.canvas.height=H}
}
export function renderSky(renderer,{style,hour=12,quality=1,dt=.016}){
 const {ctx,canvas}=renderer;renderer.time+=dt;const W=canvas.width,H=canvas.height,d=skyDescriptor(style,hour),b=vfxBudget(style,{quality});
 const g=ctx.createLinearGradient(0,0,0,H);g.addColorStop(0,css(d.zenith));g.addColorStop(1,css(d.horizon));ctx.fillStyle=g;ctx.fillRect(0,0,W,H);
 // stars
 for(const p of deterministicParticles('star',b.stars,W,H,renderer.time,31)){ctx.beginPath();ctx.arc(p.x,p.y,p.r,0,Math.PI*2);ctx.fillStyle=`rgba(235,238,224,${p.alpha*d.stars})`;ctx.fill()}
 // sun/moon
 if(d.celestial.above||style.phase==='NIGHT'){const x=d.celestial.x/1000*W,y=d.celestial.y/600*H;ctx.beginPath();ctx.arc(x,y,style.phase==='NIGHT'?9:15,0,Math.PI*2);ctx.fillStyle=css(d.celestial,style.phase==='NIGHT'?.72:.92);ctx.fill()}
 // clouds - natural opaque masses, no glow
 const cloudAlpha=d.cloudOpacity;
 for(let i=0;i<b.clouds;i++){const x=((i*193+renderer.time*(8+style.wind*18))%(W+300))-150,y=H*(.12+.28*((i*37)%11)/10),rw=90+((i*61)%140),rh=18+((i*29)%38);ctx.beginPath();ctx.ellipse(x,y,rw,rh,0,0,Math.PI*2);ctx.fillStyle=`rgba(92,96,96,${cloudAlpha*(.24+.35*((i%5)/4))})`;ctx.fill()}
 // mist
 for(const p of deterministicParticles('mist',b.mist,W,H,renderer.time,43)){ctx.beginPath();ctx.ellipse(p.x,p.y,p.r,p.r*.28,0,0,Math.PI*2);ctx.fillStyle=`rgba(154,157,151,${p.alpha})`;ctx.fill()}
 // wind streaks
 ctx.lineWidth=1;for(const p of deterministicParticles('wind',b.windStreaks,W,H,renderer.time,57)){ctx.beginPath();ctx.moveTo(p.x,p.y);ctx.lineTo(p.x+p.len,p.y+p.len*.08);ctx.strokeStyle=`rgba(210,210,196,${p.alpha})`;ctx.stroke()}
 // rain
 ctx.lineWidth=1.1;for(const p of deterministicParticles('rain',b.rain,W,H,renderer.time,71)){ctx.beginPath();ctx.moveTo(p.x,p.y);ctx.lineTo(p.x+p.drift,p.y+p.len);ctx.strokeStyle=`rgba(176,187,188,${.18+.32*style.precipitation})`;ctx.stroke()}
 renderer.last={style,hour,budget:b,descriptor:d};return renderer.last;
}
